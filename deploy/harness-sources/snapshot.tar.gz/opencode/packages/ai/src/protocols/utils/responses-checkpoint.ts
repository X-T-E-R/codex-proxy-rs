import { Effect, Schema, Stream } from "effect"
import { Route, type RouteBody, type TriggerCompactOperation } from "../../route/client.js"
import { Protocol } from "../../route/protocol.js"
import { CompactionCheckpointResponse, LLMEvent, LLMRequest } from "../../schema/index.js"
import { OpenResponses } from "../open-responses.js"
import { ProviderShared } from "../shared.js"

interface State {
  readonly parser: Pick<OpenResponses.ParserState, "id" | "provider" | "outputItems">
  readonly checkpoints: Readonly<Record<string, CompactionCheckpointResponse["checkpoint"]>>
  readonly responseID?: string
}

const onOutputItem = Effect.fnUntraced(function* (
  state: State,
  input: OpenResponses.Event,
) {
  const event = OpenResponses.normalize(state.parser, input)
  const item = event.item
  if (!item) return state
  const parser =
    event.output_index === undefined || state.parser.outputItems[event.output_index] === item.id
      ? state.parser
      : { ...state.parser, outputItems: { ...state.parser.outputItems, [event.output_index]: item.id } }
  const next = parser === state.parser ? state : { ...state, parser }
  if (event.type === "response.output_item.added" || item.type !== "compaction") return next
  if (
    event.output_index !== undefined &&
    Object.entries(state.parser.outputItems).some(
      ([index, id]) => id === item.id && Number(index) !== event.output_index,
    )
  )
    return yield* ProviderShared.eventError(parser.id, "Compaction checkpoint appeared in multiple output slots")
  if (!item.encrypted_content)
    return yield* ProviderShared.eventError(parser.id, "Compaction output is missing its encrypted content")
  const previous = state.checkpoints[item.id]
  if (previous && previous.encrypted !== item.encrypted_content)
    return yield* ProviderShared.eventError(parser.id, "Compaction output changed after completion")
  if (previous) return next
  return {
    ...next,
    checkpoints: {
      ...state.checkpoints,
      [item.id]: { type: "compaction", provider: parser.provider, id: item.id, encrypted: item.encrypted_content },
    },
  } satisfies State
})

/** Collect a trigger response before acknowledging transport completion. No generation output escapes. */
export const make = <Body>(body: RouteBody<Body>): TriggerCompactOperation =>
  Effect.fn("ResponsesCheckpoint.execute")(function* (request, executor, options) {
    const source = request.model.route
    let result: CompactionCheckpointResponse | undefined
    // Route registries erase the frame type. The codec validates that boundary before parsing.
    const event: Schema.Codec<OpenResponses.Event, unknown> = OpenResponses.protocol.stream.event
    const protocol = Protocol.make({
      id: source.protocol,
      body,
      stream: {
        event,
        initial: (request: LLMRequest): State => ({
          parser: { id: source.id, provider: request.model.provider, outputItems: {} },
          checkpoints: {},
        }),
        terminal: OpenResponses.terminal,
        step: Effect.fnUntraced(function* (state: State, event: OpenResponses.Event) {
          if (event.response?.id && state.responseID && event.response.id !== state.responseID)
            return yield* ProviderShared.eventError(source.id, "Compaction response ID changed during execution")
          if (event.type === "response.created") return [{ ...state, responseID: event.response?.id }, []] as const
          if (event.type === "error" || event.type === "response.failed")
            return yield* OpenResponses.providerFailure(event, "Compaction request failed")
          if (event.type === "response.incomplete")
            return yield* ProviderShared.eventError(source.id, "Compaction response was incomplete")
          if (event.type === "response.output_item.added" || event.type === "response.output_item.done")
            return [yield* onOutputItem(state, event), []] as const
          if (event.type !== "response.completed") return [state, []] as const
          const responseID = event.response?.id
          if (!responseID?.trim())
            return yield* ProviderShared.eventError(source.id, "Compaction response is missing its response ID")
          if (event.response?.status !== undefined && event.response.status !== "completed")
            return yield* ProviderShared.eventError(source.id, "Compaction response did not complete successfully")
          let next = state
          for (const [index, item] of (event.response?.output ?? []).entries()) {
            next = yield* onOutputItem(next, { type: "response.output_item.done", output_index: index, item })
          }
          const checkpoints = Object.values(next.checkpoints)
          const checkpoint = checkpoints[0]
          if (checkpoints.length !== 1 || !checkpoint)
            return yield* ProviderShared.eventError(
              source.id,
              "Compaction response must contain exactly one checkpoint",
            )
          result = new CompactionCheckpointResponse({
            checkpoint,
            responseID,
            usage: OpenResponses.mapUsage(event.response?.usage, OpenResponses.metadataKey(request.model)),
          })
          return [next, [LLMEvent.finish({ reason: { normalized: "stop" } })]] as const
        }),
      },
    })
    const route = Route.make({
      id: source.id,
      provider: source.provider,
      providerMetadataKey: source.providerMetadataKey,
      protocol,
      endpoint: source.endpoint,
      auth: source.auth,
      transport: source.transport,
    })
    const native = yield* body.from(request)
    const prepared = yield* route.prepareTransport(native, request, options)
    yield* route.streamPrepared(prepared, request, { http: executor }, options).pipe(Stream.runDrain)
    if (!result) return yield* ProviderShared.eventError(source.id, "Compaction response ended without a checkpoint")
    return result
  })

export * as ResponsesCheckpoint from "./responses-checkpoint.js"
