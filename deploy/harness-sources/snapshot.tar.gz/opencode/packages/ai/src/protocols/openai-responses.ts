import { Effect, Schema } from "effect"
import { Base64 } from "effect/encoding"
import { Headers } from "effect/http"
import { Route } from "../route/client.js"
import { Auth } from "../route/auth.js"
import { Endpoint } from "../route/endpoint.js"
import { Protocol } from "../route/protocol.js"
import { HttpTransport } from "../route/transport/index.js"
import { LLMRequest, type ToolDefinition, type ToolEntry } from "../schema/index.js"
import { requestTTL } from "../cache-policy.js"
import { resolveEffortUpdates } from "../effort-updates.js"
import { OpenResponses } from "./open-responses.js"
import { OpenResponsesOptions } from "./utils/open-responses-options.js"
import { JsonObject, lenient, optionalArray, optionalNull, ProviderShared } from "./shared.js"
import { ResponsesHostedTools } from "./utils/responses-hosted-tools.js"
import { OpenResponsesChannel } from "./open-responses-channel.js"
import { ResponsesCompaction } from "./utils/responses-compaction.js"
import { ResponsesCheckpoint } from "./utils/responses-checkpoint.js"
import * as Cache from "./utils/cache.js"

const ADAPTER = "openai-responses"
const NAME = "OpenAI Responses"
const WEBSOCKET_PROTOCOL_HEADER = "responses_websockets=2026-02-06"
const WEBSOCKET_ROTATE_AFTER_MS = 55 * 60 * 1000
export const DEFAULT_BASE_URL = "https://api.openai.com/v1"
export const PATH = OpenResponses.PATH

export const ContextManagement = Schema.Array(
  Schema.Struct({
    type: Schema.Literal("compaction"),
    compactThreshold: Schema.optional(Schema.Int.check(Schema.isGreaterThan(0))),
  }),
)
export type ContextManagement = typeof ContextManagement.Type

export const ReasoningMode = ProviderShared.knownString<"standard" | "pro">()
export type ReasoningMode = typeof ReasoningMode.Type
export const ReasoningContext = ProviderShared.knownString<"auto" | "current_turn" | "all_turns">()
export type ReasoningContext = typeof ReasoningContext.Type

const ReasoningOptions = Schema.Struct({
  reasoningMode: lenient(ReasoningMode),
  reasoningContext: lenient(ReasoningContext),
})

const OpenAIResponsesImageGenerationTool = Schema.Struct({
  type: Schema.tag("image_generation"),
  action: Schema.optional(Schema.Literals(["auto", "generate", "edit"])),
  background: Schema.optional(Schema.Literals(["auto", "opaque", "transparent"])),
  input_fidelity: Schema.optional(Schema.Literals(["low", "high"])),
  output_compression: Schema.optional(Schema.Int.check(Schema.isBetween({ minimum: 0, maximum: 100 }))),
  output_format: Schema.optional(Schema.Literals(["png", "jpeg", "webp"])),
  partial_images: Schema.optional(Schema.Int.check(Schema.isGreaterThanOrEqualTo(0))),
  quality: Schema.optional(Schema.Literals(["auto", "low", "medium", "high"])),
  size: Schema.optional(
    Schema.String.check(
      Schema.makeFilter((value) => {
        if (value === "auto") return undefined
        const match = /^(\d+)x(\d+)$/.exec(value)
        if (!match) return "image size must be `auto` or `{width}x{height}`"
        return Number(match[1]) > 0 && Number(match[2]) > 0 ? undefined : "image dimensions must be positive integers"
      }),
    ),
  ),
})

const OpenAIResponsesHostedToolItem = Schema.Union([
  Schema.StructWithRest(
    Schema.Struct({
      type: Schema.tag("computer_call"),
      id: Schema.String,
      status: Schema.optional(Schema.String),
      call_id: Schema.optional(Schema.String),
      action: optionalNull(JsonObject),
      pending_safety_checks: Schema.optional(Schema.Array(JsonObject)),
    }),
    [JsonObject],
  ),
  Schema.StructWithRest(
    Schema.Struct({
      type: Schema.tag("web_search_preview_call"),
      id: Schema.String,
      status: Schema.optional(Schema.String),
      action: optionalNull(JsonObject),
    }),
    [JsonObject],
  ),
  Schema.StructWithRest(
    Schema.Struct({
      type: Schema.tag("image_generation_call"),
      id: Schema.String,
      status: Schema.optional(Schema.String),
      result: optionalNull(Schema.String),
      output_format: Schema.optional(Schema.Literals(["png", "jpeg", "webp"])),
      revised_prompt: optionalNull(Schema.String),
    }),
    [JsonObject],
  ),
])

const OpenAIResponsesNamespace = Schema.Struct({
  type: Schema.tag("namespace"),
  name: Schema.String,
  description: Schema.String,
  tools: Schema.Array(OpenResponses.Tool),
})

const OpenAIResponsesTools = Schema.Union([
  OpenResponses.Tool,
  OpenAIResponsesNamespace,
  OpenAIResponsesImageGenerationTool,
])

const OpenAIResponsesToolChoice = Schema.Union([
  OpenResponses.ToolChoice,
  Schema.Struct({ type: Schema.tag("image_generation") }),
])

const OpenAIResponsesCoreFields = {
  ...OpenResponses.coreFields,
  prompt_cache_retention: Schema.optional(Schema.String),
  prompt_cache_options: Schema.optional(Schema.Struct({ ttl: Schema.optional(Schema.String) })),
  tools: optionalArray(OpenAIResponsesTools),
  tool_choice: Schema.optional(OpenAIResponsesToolChoice),
  reasoning: Schema.optional(
    Schema.Struct({
      effort: Schema.optional(OpenResponsesOptions.ReasoningEffort),
      summary: Schema.optional(Schema.Literals(["auto", "concise", "detailed"])),
      mode: Schema.optional(ReasoningMode),
      context: Schema.optional(ReasoningContext),
    }),
  ),
  context_management: Schema.optional(
    Schema.Array(
      Schema.Struct({
        type: Schema.Literal("compaction"),
        compact_threshold: Schema.optional(Schema.Int.check(Schema.isGreaterThan(0))),
      }),
    ),
  ),
}

const OpenAIResponsesBody = Schema.Struct({
  ...OpenAIResponsesCoreFields,
  stream: Schema.Literal(true),
})
export type OpenAIResponsesBody = Schema.Schema.Type<typeof OpenAIResponsesBody>

/** Request control, never conversation content. */
export const CompactionTrigger = Schema.Struct({ type: Schema.Literal("compaction_trigger") })
const CheckpointBody = Schema.Struct({
  ...OpenAIResponsesBody.fields,
  input: Schema.Array(Schema.Union([OpenResponses.InputItem, CompactionTrigger])),
})

const adapter = {
  id: ADAPTER,
  name: NAME,
  restoreHostedToolItem: (item: unknown) => (Schema.is(OpenAIResponsesHostedToolItem)(item) ? item : undefined),
} satisfies OpenResponses.ProviderAdapter

// GPT-6 and later default to `configuration_update` support, except in `reasoning.mode: "pro"`
// or alongside automatic `context_management` compaction.
const supportsEffortUpdates = (request: LLMRequest) => {
  if (request.providerOptions?.contextManagement !== undefined) return false
  if (request.providerOptions?.reasoningMode === "pro") return false
  if (Schema.is(Schema.Struct({ mode: Schema.Literal("pro") }))(request.http?.body?.reasoning)) return false
  const override = request.model.compatibility?.supportsEffortUpdates
  if (override !== undefined) return override
  const match = /(?:^|\/)gpt-(\d+)(?:\.\d+)?(?:-|$)/i.exec(request.model.id)
  return match !== null && Number(match[1]) >= 6
}

const nativeImageToolInput = (tool: ToolDefinition) => {
  const native = tool.native?.openai
  return ProviderShared.isRecord(native) && native.type === "image_generation" ? native : undefined
}

const nativeImageTool = (tool: ToolDefinition) => {
  const native = nativeImageToolInput(tool)
  return Schema.is(OpenAIResponsesImageGenerationTool)(native) ? native : undefined
}

const lowerTool = Effect.fnUntraced(function* (tool: ToolDefinition) {
  const native = nativeImageToolInput(tool)
  if (native !== undefined) {
    if (Schema.is(OpenAIResponsesImageGenerationTool)(native)) return native
    return yield* ProviderShared.invalidRequest("OpenAI Responses image generation tool options are invalid")
  }
  return yield* OpenResponses.lowerTool(NAME, tool)
})

// Native namespaces hold only function tools, so deeper levels flatten into
// the leaf names the same way non-native protocols flatten the whole tree.
const lowerToolEntry = Effect.fnUntraced(function* (tool: ToolEntry) {
  if (tool.type === "tool") return yield* lowerTool(tool)
  // OpenAI requires a namespace description; fall back to a generic one so a
  // missing description never blocks the request.
  return {
    type: "namespace" as const,
    name: tool.name,
    description: tool.description ?? `Tools in the ${tool.name} namespace.`,
    tools: yield* Effect.forEach(ProviderShared.flattenTools(tool.tools), (leaf) =>
      OpenResponses.lowerTool(NAME, leaf),
    ),
  }
})

const lowerTools = (request: LLMRequest) => Effect.forEach(request.tools, lowerToolEntry)

const lowerToolChoice = (toolChoice: NonNullable<LLMRequest["toolChoice"]>, tools: ReadonlyArray<ToolEntry>) =>
  ProviderShared.matchToolChoice(NAME, toolChoice, {
    auto: () => "auto" as const,
    none: () => "none" as const,
    required: () => "required" as const,
    tool: (name) =>
      tools.some((tool) => tool.type === "tool" && tool.name === name && nativeImageTool(tool) !== undefined)
        ? ({ type: "image_generation" } as const)
        : { type: "function" as const, name },
  })

const fromRequest = Effect.fn("OpenAIResponses.fromRequest")(function* (request: LLMRequest) {
  const management = yield* ProviderShared.validateWith(
    Schema.decodeUnknownEffect(Schema.UndefinedOr(ContextManagement)),
  )(request.providerOptions?.contextManagement)
  const options = OpenResponsesOptions.resolve(request)
  const reasoning = Schema.decodeUnknownSync(ReasoningOptions)(request.providerOptions ?? {})
  const updates = resolveEffortUpdates(request, options.reasoningEffort)
  const generation = OpenResponses.lowerGeneration(request, { ...options, reasoningEffort: updates.effort })
  return {
    ...(yield* OpenResponses.lowerConversation(updates.request, adapter)),
    ...generation,
    ...Cache.openAIRequestTTL(requestTTL(request)),
    ...(generation.reasoning || reasoning.reasoningMode || reasoning.reasoningContext
      ? {
          reasoning: {
            ...generation.reasoning,
            mode: reasoning.reasoningMode,
            context: reasoning.reasoningContext,
          },
        }
      : {}),
    context_management: management?.map((edit) => ({ type: edit.type, compact_threshold: edit.compactThreshold })),
    tools: request.tools.length === 0 ? undefined : yield* lowerTools(request),
    tool_choice:
      request.tools.length === 0
        ? undefined
        : (OpenResponses.allowedToolChoice(request, options) ??
          (request.toolChoice ? yield* lowerToolChoice(request.toolChoice, request.tools) : undefined)),
  }
})

const checkpointBody = {
  schema: CheckpointBody,
  from: Effect.fn("OpenAIResponses.checkpointBody")(function* (request: LLMRequest) {
    const overlay = request.http?.body
    // Complete history is required for stateless replay and SSE recovery. Raw input overrides bypass that contract.
    if (
      overlay?.input !== undefined ||
      overlay?.previous_response_id !== undefined ||
      overlay?.conversation !== undefined
    )
      return yield* ProviderShared.invalidRequest(
        "Trigger compaction requires complete canonical history, not an input or continuation override",
      )
    if (overlay?.stream !== undefined && overlay.stream !== true)
      return yield* ProviderShared.invalidRequest("Trigger compaction requires a streamed response")
    const native = yield* fromRequest(request)
    return {
      ...native,
      input: [...native.input, { type: "compaction_trigger" as const }],
    }
  }),
}

const hostedToolResult = Effect.fnUntraced(function* (item: ResponsesHostedTools.Item) {
  const isError = item.error !== undefined && item.error !== null
  if (item.type === "image_generation_call" && item.result) {
    yield* Effect.fromResult(Base64.decode(item.result)).pipe(
      Effect.mapError((cause) =>
        ProviderShared.eventError(ADAPTER, "OpenAI Responses returned invalid image base64", undefined, cause),
      ),
    )
    const format = item.output_format ?? "png"
    return {
      type: "content" as const,
      value: [
        {
          type: "file" as const,
          uri: `data:image/${format};base64,${item.result}`,
          mime: `image/${format}`,
        },
      ],
    }
  }
  return isError ? { type: "error" as const, value: item.error } : { type: "json" as const, value: item }
})

const HOSTED_TOOLS = {
  web_search_call: { name: "web_search", input: (item) => item.action ?? {} },
  web_search_preview_call: { name: "web_search_preview", input: (item) => item.action ?? {} },
  file_search_call: { name: "file_search", input: (item) => ({ queries: item.queries ?? [] }) },
  code_interpreter_call: {
    name: "code_interpreter",
    input: (item) => ({ code: item.code, container_id: item.container_id }),
  },
  computer_call: { name: "computer_use", input: (item) => item.action ?? {} },
  image_generation_call: { name: "image_generation", input: () => ({}), result: hostedToolResult },
  mcp_call: {
    name: "mcp",
    input: (item) => ({ server_label: item.server_label, name: item.name, arguments: item.arguments }),
  },
} as const satisfies ResponsesHostedTools.Definitions

const step = (state: OpenResponses.ParserState, input: OpenResponses.Event) => {
  const event = OpenResponses.normalize(state, input)
  if (event.type === "response.reasoning_text.delta")
    return event.item_id !== undefined
      ? Effect.succeed(OpenResponses.onReasoningDelta(state, event, event.item_id))
      : ProviderShared.eventError(ADAPTER, `${event.type} is missing item_id`)
  if (event.type === "response.output_item.done" && event.item && ResponsesHostedTools.isItem(event.item, HOSTED_TOOLS))
    return ResponsesHostedTools.onDone(state, event.item, HOSTED_TOOLS)
  return OpenResponses.step(state, event)
}

export const protocol = Protocol.make({
  id: ADAPTER,
  body: {
    schema: OpenAIResponsesBody,
    from: fromRequest,
  },
  stream: {
    event: OpenResponses.protocol.stream.event,
    initial: (request) => OpenResponses.initial(request, adapter),
    step,
    terminal: OpenResponses.terminal,
  },
  supportsEffortUpdates,
})

const endpoint = Endpoint.path<OpenAIResponsesBody>(PATH, { baseURL: DEFAULT_BASE_URL })
const auth = Auth.none

export const httpTransport = HttpTransport.sseJson.with<OpenAIResponsesBody>()
export const channelTransport = OpenResponsesChannel.transport<OpenAIResponsesBody>
export const transport = channelTransport({
  id: ADAPTER,
  name: NAME,
  rotateAfterMs: WEBSOCKET_ROTATE_AFTER_MS,
  headers: (headers) => Headers.set(headers, "openai-beta", headers["openai-beta"] ?? WEBSOCKET_PROTOCOL_HEADER),
})

export const route = Route.make({
  compact: {
    endpoint: ResponsesCompaction.make(adapter, lowerTools),
    trigger: ResponsesCheckpoint.make(checkpointBody),
  },
  id: ADAPTER,
  provider: "openai",
  providerMetadataKey: "openai",
  protocol,
  endpoint,
  auth,
  transport,
  defaults: { providerOptions: { store: false, include: ["reasoning.encrypted_content"] } },
})

export * as OpenAIResponses from "./openai-responses.js"
