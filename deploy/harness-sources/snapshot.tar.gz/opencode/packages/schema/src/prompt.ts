import { Schema } from "effect"
import { optional } from "./schema.js"
import { statics } from "./schema.js"
import { Skill } from "./skill.js"

export interface PromptMention extends Schema.Schema.Type<typeof PromptMention> {}
export const PromptMention = Schema.Struct({
  start: Schema.Finite,
  end: Schema.Finite,
  text: Schema.String,
}).annotate({ identifier: "Prompt.Mention" })

export const FileSource = Schema.Union([
  Schema.Struct({ type: Schema.Literal("inline") }),
  Schema.Struct({ type: Schema.Literal("uri"), uri: Schema.String }),
])
  .pipe(Schema.toTaggedUnion("type"))
  .annotate({ identifier: "Prompt.FileSource" })
export type FileSource = typeof FileSource.Type

// The canonical pattern backtracks on large inputs, so it only supplies metadata (OpenAPI, errors) while an equivalent linear check runs.
export const Base64 = Schema.String.check(
  Schema.makeFilter(
    (value: string) => value.length % 4 === 0 && /^[A-Za-z0-9+/]*={0,2}$/u.test(value),
    Schema.isPattern(/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/u).annotations,
  ),
).annotate({ identifier: "Prompt.Base64" })
export type Base64 = typeof Base64.Type

export interface FileAttachment extends Schema.Schema.Type<typeof FileAttachment> {}
export const FileAttachment = Schema.Struct({
  data: Base64,
  mime: Schema.String,
  source: FileSource,
  name: Schema.String.pipe(optional),
  description: Schema.String.pipe(optional),
  mention: PromptMention.pipe(optional),
})
  .annotate({ identifier: "Prompt.FileAttachment" })
  .pipe(
    statics((schema) => ({
      create: (input: FileAttachment) =>
        schema.make({
          data: input.data,
          mime: input.mime,
          source: input.source,
          name: input.name,
          description: input.description,
          mention: input.mention,
        }),
    })),
  )

/** `media:` and the lowercase hex SHA-256 of a stored blob's bytes. Names no server route. */
export const MediaRef = Schema.String.check(Schema.isPattern(/^media:[0-9a-f]{64}$/)).annotate({
  identifier: "Prompt.MediaRef",
})
export type MediaRef = typeof MediaRef.Type

const { data: _, ...fileAttachmentFields } = FileAttachment.fields

/**
 * An attachment whose bytes stay on the server, sent to clients that opt in with the experimental `experimental-media-uri`
 * capability. Fetch the bytes from `GET /api/experimental/media/:hash`.
 */
export interface MediaFileAttachment extends Schema.Schema.Type<typeof MediaFileAttachment> {}
export const MediaFileAttachment = Schema.Struct({
  ...fileAttachmentFields,
  uri: MediaRef,
  bytes: Schema.Int.pipe(optional),
  width: Schema.Int.pipe(optional),
  height: Schema.Int.pipe(optional),
}).annotate({ identifier: "Prompt.MediaFileAttachment" })

export const Attachment = Schema.Union([FileAttachment, MediaFileAttachment]).annotate({
  identifier: "Prompt.Attachment",
})
export type Attachment = typeof Attachment.Type

export interface AgentAttachment extends Schema.Schema.Type<typeof AgentAttachment> {}
export const AgentAttachment = Schema.Struct({
  name: Schema.String,
  mention: PromptMention.pipe(optional),
}).annotate({ identifier: "Prompt.AgentAttachment" })

export interface SkillAttachment extends Schema.Schema.Type<typeof SkillAttachment> {}
export const SkillAttachment = Schema.Struct({
  id: Skill.ID,
  name: Skill.Name,
  text: Schema.String.pipe(optional),
  mention: PromptMention.pipe(optional),
}).annotate({ identifier: "Prompt.SkillAttachment" })

export interface Prompt extends Schema.Schema.Type<typeof Prompt> {}
export const Prompt = Schema.Struct({
  text: Schema.String,
  files: Schema.Array(FileAttachment).pipe(optional),
  agents: Schema.Array(AgentAttachment).pipe(optional),
  skills: Schema.Array(SkillAttachment).pipe(optional),
})
  .annotate({ identifier: "Prompt" })
  .pipe(
    statics((schema) => ({
      equivalence: Schema.toEquivalence(schema),
      fromUserMessage: (input: Pick<Prompt, "text" | "files" | "agents" | "skills">) =>
        schema.make({
          text: input.text,
          ...(input.files === undefined ? {} : { files: input.files }),
          ...(input.agents === undefined ? {} : { agents: input.agents }),
          ...(input.skills === undefined ? {} : { skills: input.skills }),
        }),
    })),
  )
