import { Schema } from "effect"
import { statics } from "./schema.js"

export const ProjectID = Schema.String.pipe(
  Schema.brand("Project.ID"),
  Schema.annotate({ identifier: "Project.ID" }),
  statics((schema) => ({ global: schema.make("global") })),
)
export type ProjectID = typeof ProjectID.Type
